export type ProjectDifficulty = 'Beginner' | 'Intermediate' | 'Advanced';
export type ProjectStatus = 'Planning' | 'Development' | 'Testing' | 'Completed';
export type TaskPriority = 'High' | 'Medium' | 'Low';
export type TaskStatus = 'Not Started' | 'In Progress' | 'Completed';

export interface Project {
  id: string;
  name: string;
  description: string;
  domain: string;
  difficulty: ProjectDifficulty;
  technologies: string[];
  status: ProjectStatus;
  progress: number;
  startDate: string;
  targetDate: string;
  teamSize?: string;
  githubUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  projectId: string;
  phaseId: string;
  phaseName: string;
  title: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  estimatedTime: string;
  dueDate?: string;
  dependencies?: string[];
}

export interface Phase {
  id: string;
  phaseNumber: number;
  title: string;
  description: string;
  tasks: Task[];
}

export interface ProjectIdea {
  title: string;
  problemStatement: string;
  proposedSolution: string;
  targetUsers: string;
  mainObjectives: string[];
  keyFeatures: string[];
  recommendedTechStack: {
    frontend: string;
    backend: string;
    database: string;
    aiMl: string;
    deployment: string;
  };
  aiComponents: string[];
  expectedDifficulty: ProjectDifficulty;
  estimatedDevelopmentTime: string;
  possibleFutureEnhancements: string[];
}

export interface ProjectAnalysis {
  problemClarity: { score: number; feedback: string };
  targetUsers: string;
  technicalFeasibility: { score: number; assessment: string };
  requiredModules: string[];
  suggestedTechnology: {
    frontend: string;
    backend: string;
    database: string;
    ai: string;
  };
  aiOpportunities: string[];
  missingComponents: string[];
  possibleChallenges: { challenge: string; solution: string }[];
  suggestedImprovements: string[];
}

export type CodeActionType =
  | 'explain'
  | 'find_bug'
  | 'fix'
  | 'explain_error'
  | 'improve'
  | 'example'
  | 'optimize'
  | 'test_cases'
  | 'generate_code'
  | 'modify_code'
  | 'fix_error';

export interface CodeMentorRequest {
  code: string;
  language: string;
  errorMessage?: string;
  goal?: string;
  action: CodeActionType;
}

export interface CodeMentorResponse {
  action: CodeActionType;
  problemSummary: string;
  whyItHappens: string;
  detailedExplanation: string;
  correctedCode: string;
  whatChanged: string[];
  exampleUsage: string;
  expectedOutput: string;
  learningTip: string;
}

export interface DocumentationRequest {
  projectName: string;
  description: string;
  features: string;
  techStack: string;
  aiTechnologies: string;
  database: string;
  teamSize?: string;
  installationRequirements?: string;
  projectStatus?: string;
}

export interface ProjectDocumentation {
  projectName: string;
  overview: string;
  problemStatement: string;
  objectives: string[];
  features: string[];
  techStack: { category: string; tools: string[] }[];
  systemArchitecture: string;
  moduleDescriptions: { name: string; purpose: string; responsibilities: string[] }[];
  installationSteps: { step: number; title: string; command?: string; description: string }[];
  usageInstructions: string;
  aiImplementation: string;
  databaseSchema: string;
  testingSection: string;
  futureEnhancements: string[];
  conclusion: string;
  readmeMarkdown: string;
}

export type CategoryEvaluationStatus = 'Strong' | 'Adequate' | 'Needs Attention' | 'Critical Missing';

export interface CategoryEvaluation {
  name: string;
  status: CategoryEvaluationStatus;
  score: number; // 0-10
  findings: string[];
  suggestions: string[];
}

export interface ProjectEvaluation {
  overallScore: number; // 0-100
  readinessStatus: 'Initial Stage' | 'In Progress' | 'Beta Ready' | 'Presentation Ready';
  categories: CategoryEvaluation[];
  readinessDashboard: {
    featuresCompletedStatus: string;
    documentationStatus: string;
    testingStatus: string;
    deploymentStatus: string;
    aiImplementationStatus: string;
    remainingCriticalTasks: string[];
  };
  missingItems: string[];
  nextRecommendedActions: { priority: 'High' | 'Medium' | 'Low'; action: string; impact: string }[];
}

export interface SkillItem {
  name: string;
  level: 'Beginner' | 'Intermediate' | 'Strong' | 'None';
  relevance: string;
}

export interface SkillToLearn {
  name: string;
  importance: 'Must-have' | 'Important' | 'Nice-to-have';
  reason: string;
  estimatedHours: string;
  learningOrder: number;
  suggestedPracticeTasks: string[];
}

export interface SkillGapAnalysis {
  knownSkills: SkillItem[];
  skillsToLearn: SkillToLearn[];
  learningRoadmapSummary: string;
}

export interface TechRecommendation {
  frontend: { tech: string; reason: string; freeTierNotes: string };
  backend: { tech: string; reason: string; freeTierNotes: string };
  database: { tech: string; reason: string; freeTierNotes: string };
  aiMlFramework: { tech: string; reason: string; freeTierNotes: string };
  apis: { name: string; reason: string; freeTierNotes: string }[];
  deployment: { option: string; reason: string; freeTierNotes: string };
  testingTools: { tool: string; reason: string }[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'mentor';
  text: string;
  timestamp: string;
  projectContextName?: string;
}

export interface RecentActivity {
  id: string;
  type: 'project_created' | 'task_completed' | 'ai_consultation' | 'doc_generated' | 'eval_run';
  title: string;
  description: string;
  timestamp: string;
}

export interface UserAccount {
  id: string;
  fullName: string;
  email: string;
  collegeOrUniversity?: string;
  degreeOrBranch?: string;
  semesterOrYear?: string;
  studentId?: string;
  avatarInitials: string;
  createdAt: string;
  lastLoginAt: string;
}

export interface AuthSession {
  user: UserAccount;
  token: string;
}

export interface AIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  isFallback?: boolean;
}
