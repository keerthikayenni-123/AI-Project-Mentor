export interface StudentMember {
  name: string;
  rollNo: string;
  role?: string;
}

export interface DocumentMetadata {
  projectTitle: string;
  projectSubtitle: string;
  repoUrl: string;
  documentRef: string;
  standard: string;
  version: string;
  submissionDate: string;
  academicYear: string;
  institutionName: string;
  institutionSubtitle: string;
  department: string;
  degree: string;
  students: StudentMember[];
  guideName: string;
  guideDesignation: string;
  guideDepartment: string;
  hodName: string;
  coordinatorName: string;
}

export interface TableRow {
  [key: string]: string;
}

export interface TableData {
  headers: string[];
  rows: string[][];
  caption?: string;
}

export interface DiagramData {
  title: string;
  asciiArt?: string;
  caption: string;
  type: 'architecture' | 'flow' | 'dfd' | 'erd' | 'sequence';
}

export interface FunctionalRequirement {
  id: string;
  title: string;
  priority: 'High' | 'Medium' | 'Low';
  description: string;
  inputs?: string;
  outputs?: string;
}

export interface TestCase {
  id: string;
  feature: string;
  scenario: string;
  inputs: string;
  expectedResult: string;
  status: 'Pass' | 'Verified';
}

export interface SRSPage {
  pageNumber: number;
  title: string;
  headerTitle: string;
  sections: Array<{
    heading?: string;
    subheading?: string;
    paragraphs?: string[];
    bullets?: string[];
    table?: TableData;
    diagram?: DiagramData;
    callout?: {
      type: 'info' | 'important' | 'quote';
      title?: string;
      text: string;
    };
    customComponent?: string;
  }>;
}
