import { Project, Task, ProjectStatus, TaskPriority, TaskStatus } from '../types';
import { storageService } from './storageService';

export const projectService = {
  getAllProjects(): Project[] {
    return storageService.getProjects();
  },

  getProject(id: string): Project | undefined {
    return storageService.getProjectById(id);
  },

  createProject(data: {
    name: string;
    description: string;
    domain: string;
    difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
    technologies: string[];
    startDate: string;
    targetDate: string;
    teamSize?: string;
    githubUrl?: string;
  }): Project {
    return storageService.saveProject({
      ...data,
      status: 'Planning' as ProjectStatus,
    });
  },

  updateProject(project: Project): Project {
    return storageService.updateProject(project);
  },

  deleteProject(id: string): void {
    storageService.deleteProject(id);
  },

  getActiveProject(): Project | undefined {
    return storageService.getActiveProject();
  },

  setActiveProject(id: string): void {
    storageService.setActiveProjectId(id);
  },

  getProjectTasks(projectId: string): Task[] {
    return storageService.getTasks(projectId);
  },

  addTask(data: {
    projectId: string;
    phaseId: string;
    phaseName: string;
    title: string;
    description: string;
    priority: TaskPriority;
    status: TaskStatus;
    estimatedTime: string;
    dueDate?: string;
  }): Task {
    return storageService.saveTask(data);
  },

  toggleTask(taskId: string): Task | undefined {
    return storageService.toggleTaskStatus(taskId);
  },

  deleteTask(taskId: string): void {
    storageService.deleteTask(taskId);
  },

  saveRoadmapTasks(projectId: string, phases: any[]): Task[] {
    const newTasks: Omit<Task, 'id'>[] = [];

    phases.forEach((phase) => {
      const phaseId = `phase-${phase.phaseNumber || Math.random()}`;
      const phaseName = phase.title;

      (phase.tasks || []).forEach((t: any) => {
        newTasks.push({
          projectId,
          phaseId,
          phaseName,
          title: t.title,
          description: t.description || '',
          priority: (t.priority as TaskPriority) || 'Medium',
          status: 'Not Started',
          estimatedTime: t.estimatedTime || '2 days',
          dependencies: t.dependencies || [],
        });
      });
    });

    return storageService.saveBatchTasks(newTasks);
  },
};
