import {
  ProjectIdea,
  ProjectAnalysis,
  CodeMentorRequest,
  CodeMentorResponse,
  DocumentationRequest,
  ProjectDocumentation,
  ProjectEvaluation,
  SkillGapAnalysis,
  TechRecommendation,
  AIResponse,
} from '../types';
import { generateFallbackCodeMentorResponse } from './codeFallbackService';

export const aiService = {
  async generateProjectIdeas(params: {
    domain: string;
    areaOfInterest?: string;
    skills?: string;
    aiInterests?: string;
    difficulty?: string;
    techPreference?: string;
    duration?: string;
    teamType?: string;
  }): Promise<AIResponse<ProjectIdea[]>> {
    try {
      const res = await fetch('/api/ai/generate-ideas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.data,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI service error (using local resilience fallback):', err);
      return {
        success: false,
        error: 'Unable to reach AI server. Please check your network or try again.',
      };
    }
  },

  async analyzeProject(params: {
    title: string;
    description: string;
    domain?: string;
    techStack?: string;
  }): Promise<AIResponse<ProjectAnalysis>> {
    try {
      const res = await fetch('/api/ai/analyze-project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.data,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI analysis error:', err);
      return {
        success: false,
        error: 'Failed to analyze project idea. Please check your inputs.',
      };
    }
  },

  async generateRoadmap(params: {
    title: string;
    description?: string;
    domain?: string;
    techStack?: string;
    difficulty?: string;
  }): Promise<AIResponse<any[]>> {
    try {
      const res = await fetch('/api/ai/generate-roadmap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.data,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI roadmap error:', err);
      return {
        success: false,
        error: 'Failed to generate roadmap from AI. Please try again.',
      };
    }
  },

  async mentorCode(request: CodeMentorRequest): Promise<AIResponse<CodeMentorResponse>> {
    try {
      const res = await fetch('/api/ai/code-mentor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      if (json && json.data) {
        return {
          success: true,
          data: json.data,
          isFallback: json.isFallback,
        };
      }
      throw new Error('Empty payload returned from server');
    } catch (err: any) {
      console.warn('AI code mentor server request error, generating verified project code fallback:', err);
      const fallbackData = generateFallbackCodeMentorResponse(request);
      return {
        success: true,
        data: fallbackData,
        isFallback: true,
      };
    }
  },

  async generateDocumentation(
    request: DocumentationRequest
  ): Promise<AIResponse<ProjectDocumentation>> {
    try {
      const res = await fetch('/api/ai/generate-docs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.data,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI documentation error:', err);
      return {
        success: false,
        error: 'Failed to generate documentation. Please try again.',
      };
    }
  },

  async evaluateProject(params: {
    title: string;
    description: string;
    completedFeatures?: string;
    techStack?: string;
    currentProgress?: string;
    githubUrl?: string;
    documentationStatus?: string;
    knownProblems?: string;
  }): Promise<AIResponse<ProjectEvaluation>> {
    try {
      const res = await fetch('/api/ai/evaluate-project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.data,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI evaluation error:', err);
      return {
        success: false,
        error: 'Failed to evaluate project. Please verify inputs.',
      };
    }
  },

  async analyzeSkills(params: {
    targetProject: string;
    currentSkills: any[];
  }): Promise<AIResponse<SkillGapAnalysis>> {
    try {
      const res = await fetch('/api/ai/analyze-skills', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.data,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI skill analysis error:', err);
      return {
        success: false,
        error: 'Failed to analyze skill gap. Please try again.',
      };
    }
  },

  async recommendTechnologies(params: {
    projectDescription: string;
    domain?: string;
  }): Promise<AIResponse<TechRecommendation>> {
    try {
      const res = await fetch('/api/ai/recommend-tech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.data,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI tech recommend error:', err);
      return {
        success: false,
        error: 'Failed to recommend technologies. Please try again.',
      };
    }
  },

  async chatWithMentor(params: {
    message: string;
    projectContext?: any;
    history?: any[];
  }): Promise<AIResponse<string>> {
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const json = await res.json();
      return {
        success: true,
        data: json.reply,
        isFallback: json.isFallback,
      };
    } catch (err: any) {
      console.warn('AI chat error:', err);
      return {
        success: false,
        error: 'AI Mentor temporarily unavailable. Please try again.',
      };
    }
  },
};
