import { Project } from '../types';
import { DocumentMetadata, SRSPage } from '../types/srs';
import { storageService } from '../services/storageService';

// Helper to deduce domain-specific requirements, architecture, and test cases
function getDomainContext(project: Project) {
  const name = project.name.toLowerCase();
  const domain = (project.domain || '').toLowerCase();
  const desc = (project.description || '').toLowerCase();
  const tech = (project.technologies || []).join(', ');

  if (name.includes('medical') || domain.includes('health') || desc.includes('symptom') || desc.includes('patient')) {
    return {
      domainCategory: 'Healthcare & Clinical Decision Support Systems',
      problemContext: 'In acute care and ambulatory healthcare settings, delayed symptom triage results in crowded emergency waiting rooms and adverse clinical outcomes. Conventional triage systems rely on manual intake, causing triage delays exceeding 45 minutes and high variability in risk stratification. There is an urgent need for an automated, pre-clinical triage platform that captures patient-reported symptoms, computes standardized emergency severity indices, and securely routes patients to appropriate clinics.',
      primaryObjective: 'To provide 24/7 intelligent symptom intake, compute standardized emergency risk scores within 500ms, and streamline clinical consultation queues while strictly adhering to HIPAA data privacy mandates.',
      modules: [
        { id: 'FR-1', name: 'Patient Symptom Intake & Chief Complaint Parser', desc: 'Captures multi-lingual symptom descriptions, anatomical locations, onset time, and severity rating.' },
        { id: 'FR-2', name: 'Clinical Risk Stratification & Triage Scoring Engine', desc: 'Applies validated clinical decision rules to calculate Emergency Severity Index (ESI Level 1-5).' },
        { id: 'FR-3', name: 'Emergency Department & Telehealth Router', desc: 'Routes high-acuity cases to emergency services and non-emergent cases to scheduled clinic slots.' },
        { id: 'FR-4', name: 'Clinician Handover Summary & EHR Integration', desc: 'Generates structured HL7/FHIR compliant pre-clinical summaries for attending physicians.' },
      ],
      diagram: `
  +----------------------------------------------------------------------------------+
  |                              PATIENT INTERACTION TIER                            |
  |  +--------------------+  +--------------------+  +----------------------------+  |
  |  | Patient Web/Mobile |  | Symptom Form & Vitals|  | Real-Time Speech/Text Chat  |  |
  |  | React 19 Frontend  |  | Input Validator    |  | Audio/Visual Feedback      |  |
  |  +---------+----------+  +---------+----------+  +--------------+-------------+  |
  +------------|-----------------------|----------------------------|----------------+
               |                       |                            |
               +-----------------------+                            | (Secure Client
                               | HTTPS / WSS Requests               |  Session State)
                               v                                    v
  +----------------------------------------------------------------------------------+
  |                           FASTAPI / NODE.JS BACKEND CORE                         |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  | HIPAA Auth & Encryption|  | Clinical Decision      |  | Emergency Severity |  |
  |  | (AES-256 / TLS 1.3)    |  | Algorithm Engine       |  | Index (ESI Scoring)|  |
  |  +-----------+------------+  +-----------+------------+  +---------+----------+  |
  +--------------|---------------------------|-------------------------|-------------+
                 |                           |                         |
                 v                           v                         v
  +----------------------------------------------------------------------------------+
  |                          CLINICAL DATA & KNOWLEDGE TIER                          |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  | PostgreSQL Health DB   |  | Medical Knowledge Base |  | Hospital EHR /     |  |
  |  | (Encrypted at Rest)    |  | & ICD-10 Diagnostic Map|  | Telehealth Webhook |  |
  |  +------------------------+  +------------------------+  +--------------------+  |
  +----------------------------------------------------------------------------------+`,
      erd: `
  +-------------------------+            +--------------------------+
  |      PATIENT RECORD     | 1        * |      TRIAGE SESSION      |
  +-------------------------+------------+--------------------------+
  | - patientId: UUID       |            | - sessionId: UUID        |
  | - encryptedName: string |            | - chiefComplaint: string |
  | - ageGroup: string      |            | - esiScore: number (1-5) |
  | - medicalHistory: text  |            | - triageStatus: string   |
  | - vitals: JSON          |            | - createdAt: timestamp   |
  +------------+------------+            +------------+-------------+
               | 1                                    | 1
               |                                      | *
               |                         +------------+-------------+
               |                         |    SYMPTOM LOG ENTRY     |
               |                         +--------------------------+
               |                         | - entryId: UUID          |
               |                         | - symptomName: string    |
               |                         | - severity: 1 to 10      |
               |                         | - durationHours: number  |
               |                         +--------------------------+
               | 1
               v *
  +-------------------------+  +------------------------------------+
  |  CLINICAL HANDOVER DOC  |  |      EMERGENCY ESCALATION          |
  +-------------------------+  +------------------------------------+
  | - docId: UUID           |  | - alertId: UUID                    |
  | - summaryNotes: text    |  | - dispatchLevel: 'RED' | 'YELLOW'  |
  | - attendingDoctor: str  |  | - hospitalNotified: boolean        |
  | - generatedAt: timestamp|  | - triggeredAt: timestamp           |
  +-------------------------+  +------------------------------------+`,
      testCases: [
        { id: 'TC-01', req: 'FR-1 (Symptom Intake)', scenario: 'Patient inputs severe chest pain radiating to left arm', exp: 'Classifies as ESI Level 1 (Immediate Life Threat) and triggers Emergency Red Alert within 200ms', res: 'PASS' },
        { id: 'TC-02', req: 'FR-1 (Input Sanitize)', scenario: 'Patient inputs malicious script tags into symptom description', exp: 'Sanitizes string, strips script tags, records clean text symptom', res: 'PASS' },
        { id: 'TC-03', req: 'FR-2 (Scoring Math)', scenario: 'Mild headache for 2 hours with normal vital signs', exp: 'Computes ESI Level 5 (Non-urgent), schedules primary outpatient telemedicine visit', res: 'PASS' },
        { id: 'TC-04', req: 'FR-3 (Routing)', scenario: 'Pediatric patient (age 4) with high fever 104F', exp: 'Applies pediatric vital thresholds, escalates to Pediatric Urgent Care queue', res: 'PASS' },
        { id: 'TC-05', req: 'FR-4 (Handover Doc)', scenario: 'Complete triage session concludes successfully', exp: 'Generates structured clinical summary PDF with vitals, ESI score, and timeline', res: 'PASS' },
        { id: 'TC-06', req: 'PERF-01 (Latency)', scenario: '100 concurrent patient triage intake requests', exp: 'Maintains median latency below 450ms without packet loss or drop', res: 'PASS' },
        { id: 'TC-07', req: 'SEC-01 (HIPAA)', scenario: 'Inspect client network payload in browser developer tools', exp: 'All Patient Identifiable Information (PII) is tokenized with TLS 1.3 encryption', res: 'PASS' },
        { id: 'TC-08', req: 'REL-01 (Offline)', scenario: 'Hospital primary internet connection experiences outage', exp: 'Local offline triage rule table operates seamlessly on local hospital server', res: 'PASS' },
        { id: 'TC-09', req: 'EHR-01 (Export)', scenario: 'Transmit triage packet to hospital EHR endpoint', exp: 'Receives HTTP 200 OK with HL7 message acknowledgment identifier', res: 'PASS' },
        { id: 'TC-10', req: 'UI-01 (A11y)', scenario: 'Visually impaired patient accesses triage with screen reader', exp: 'Full aria-live announcements and WCAG 2.1 AA compliant contrast delivered', res: 'PASS' },
      ],
    };
  }

  if (name.includes('attendance') || domain.includes('education') || desc.includes('student') || desc.includes('campus')) {
    return {
      domainCategory: 'Educational Data Mining & Predictive Academic Analytics',
      problemContext: 'Undergraduate engineering programs experience student dropout rates and exam ineligibility primarily attributable to unmonitored chronic absenteeism. Conventional paper registers and isolated biometric machines fail to provide predictive early warnings to academic counselors. By the time final semester attendance shortages are tabulated, remediation is impossible. An integrated predictive analytics system is imperative to track real-time attendance trajectories and forecast semester eligibility risks weeks in advance.',
      primaryObjective: 'To aggregate real-time lecture attendance, predict semester exam debarment risk using regression and classification algorithms with >92% accuracy, and deliver proactive multi-channel alerts to students, faculty guides, and parents.',
      modules: [
        { id: 'FR-1', name: 'Multi-Modal Attendance Ingestion & Verification', desc: 'Ingests lecture attendance via RFID, biometric devices, and faculty digital sign-off with anti-proxy validations.' },
        { id: 'FR-2', name: 'Predictive Absenteeism & Debarment Risk Engine', desc: 'Machine learning model predicting final attendance percentage based on historical patterns and course difficulty.' },
        { id: 'FR-3', name: 'Early Warning & Multi-Tier Notification Dispatcher', desc: 'Automates threshold alerts (<75% warning, <65% critical) via SMS, email, and mobile push notifications.' },
        { id: 'FR-4', name: 'Institutional Analytics & HOD Compliance Portal', desc: 'Generates departmental compliance heatmaps, subject-wise deficit reports, and mandatory university attendance registers.' },
      ],
      diagram: `
  +----------------------------------------------------------------------------------+
  |                               CAMPUS INGESTION TIER                              |
  |  +--------------------+  +--------------------+  +----------------------------+  |
  |  | Classroom Biometric|  | Faculty Mobile App |  | Student Portal Dashboard   |  |
  |  | RFID / Smart Card  |  | Manual Verification|  | (React / Tailwind UI)      |  |
  |  +---------+----------+  +---------+----------+  +--------------+-------------+  |
  +------------|-----------------------|----------------------------|----------------+
               |                       |                            |
               +-----------------------+                            |
                               | Real-Time Attendance Stream        |
                               v                                    v
  +----------------------------------------------------------------------------------+
  |                           CORE STREAMLIT / NODE SERVICE                          |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  | Proxy Detection &      |  | Scikit-Learn Predictive|  | Automated Alert    |  |
  |  | Deduplication Filter   |  | Analytics Model        |  | Dispatcher Service |  |
  |  +-----------+------------+  +-----------+------------+  +---------+----------+  |
  +--------------|---------------------------|-------------------------|-------------+
                 |                           |                         |
                 v                           v                         v
  +----------------------------------------------------------------------------------+
  |                       DATA REPOSITORY & COMPLIANCE RECORDS                       |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  | SQLite / PostgreSQL    |  | Semester Attendance    |  | Institutional SMS  |  |
  |  | Academic Registry      |  | Historical Timeseries  |  | & Email Gateway    |  |
  |  +------------------------+  +------------------------+  +--------------------+  |
  +----------------------------------------------------------------------------------+`,
      erd: `
  +-------------------------+            +--------------------------+
  |     STUDENT RECORD      | 1        * |     ATTENDANCE LOG       |
  +-------------------------+------------+--------------------------+
  | - rollNo: string (PK)   |            | - logId: UUID            |
  | - studentName: string   |            | - subjectCode: string    |
  | - department: string    |            | - date: timestamp        |
  | - currentSemester: int  |            | - status: 'P' | 'A' | 'L'|
  | - overallPercent: float |            | - verifiedByFaculty: bool|
  +------------+------------+            +--------------------------+
               | 1
               | 1
               v
  +-------------------------+            +--------------------------+
  |     RISK PROJECTION     | 1        * |     DISPATCHED ALERT     |
  +-------------------------+------------+--------------------------+
  | - projectionId: UUID    |            | - alertId: UUID          |
  | - predictedPercent: flt |            | - recipientEmail: string |
  | - debarmentRisk: string |            | - severity: 'HIGH'|'MED' |
  | - modelConfidence: flt  |            | - deliveredAt: timestamp |
  +-------------------------+            +--------------------------+`,
      testCases: [
        { id: 'TC-01', req: 'FR-1 (Ingestion)', scenario: 'Student swipes RFID card twice within 10 seconds for same lecture', exp: 'Detects duplicate entry, records single valid attendance stamp without double-counting', res: 'PASS' },
        { id: 'TC-02', req: 'FR-2 (Risk Model)', scenario: 'Student misses 4 consecutive lectures in week 3', exp: 'Forecasts final attendance below 70%, marks status as "High Risk"', res: 'PASS' },
        { id: 'TC-03', req: 'FR-3 (Alerts)', scenario: 'Student attendance drops below mandatory 75% threshold', exp: 'Dispatches automated email alert to student and faculty mentor within 60 seconds', res: 'PASS' },
        { id: 'TC-04', req: 'FR-4 (Reports)', scenario: 'HOD requests semester attendance consolidated sheet for 120 students', exp: 'Generates comprehensive tabular PDF and Excel export with percentage distribution', res: 'PASS' },
        { id: 'TC-05', req: 'UI-01 (Student View)', scenario: 'Student logs in to inspect current attendance and projected margin', exp: 'Displays circular progress gauge with exact number of permissible leaves remaining', res: 'PASS' },
        { id: 'TC-06', req: 'PERF-01 (Load)', scenario: 'Simultaneous 500 attendance records submitted during morning bell', exp: 'Processes full batch in under 800ms with zero database lock contentions', res: 'PASS' },
        { id: 'TC-07', req: 'SEC-01 (Role)', scenario: 'Student attempts to edit attendance log via browser API request', exp: 'Returns HTTP 403 Forbidden; restricts write mutations strictly to faculty guides', res: 'PASS' },
        { id: 'TC-08', req: 'REL-01 (Recovery)', scenario: 'Power glitch occurs during biometric attendance sync', exp: 'Transaction rollback maintains database integrity; resumes cleanly on restart', res: 'PASS' },
        { id: 'TC-09', req: 'ML-01 (Accuracy)', scenario: 'Run predictive model against historical test cohort of 500 students', exp: 'Demonstrates Area Under Curve (AUC) > 0.93 for semester debarment classification', res: 'PASS' },
        { id: 'TC-10', req: 'EXP-01 (Audit)', scenario: 'Academic audit committee requests 3-year historical attendance log', exp: 'Produces tamper-evident historical audit trail with faculty sign-off stamps', res: 'PASS' },
      ],
    };
  }

  if (name.includes('finance') || domain.includes('fin') || desc.includes('expense') || desc.includes('budget')) {
    return {
      domainCategory: 'Financial Technology & Intelligent Budget Management',
      problemContext: 'Young professionals and university students struggle with financial literacy, resulting in overspending, unpredictable cash flow shortages, and zero systematic investment allocation. Traditional banking portals provide rigid static statements without forward-looking intelligence. An intelligent personal finance assistant that automates statement parsing, categorizes expenditures, forecasts end-of-month balances, and prescribes micro-budgeting strategies is required to achieve personal financial resilience.',
      primaryObjective: 'To deliver automated transaction ingestion, machine-learning spending classification with >95% accuracy, predictive end-of-month cash flow forecasting, and encrypted client-side data sovereignty.',
      modules: [
        { id: 'FR-1', name: 'Digital Statement Ingestion & OCR Parser', desc: 'Parses PDF, CSV, and OFX bank statements with automated transaction reconciliation.' },
        { id: 'FR-2', name: 'Intelligent Categorization & Merchant Classifier', desc: 'Classifies transactions into Food, Utilities, Education, and Entertainment using NLP heuristics.' },
        { id: 'FR-3', name: 'Cash Flow Forecasting & Budget Anomaly Engine', desc: 'Forecasts upcoming recurring expenses and flags unusual debit velocity against historical baselines.' },
        { id: 'FR-4', name: 'Personalized Financial Health Scorecard & Insights', desc: 'Computes monthly financial health index (0-100) and outputs prioritized savings recommendations.' },
      ],
      diagram: `
  +----------------------------------------------------------------------------------+
  |                           USER INTERFACE & SECURITY TIER                         |
  |  +--------------------+  +--------------------+  +----------------------------+  |
  |  | Responsive React   |  | Interactive Charts |  | Client-Side AES-256        |  |
  |  | Financial Dashboard|  | (Chart.js / Motion)|  | Encryption Vault           |  |
  |  +---------+----------+  +---------+----------+  +--------------+-------------+  |
  +------------|-----------------------|----------------------------|----------------+
               |                       |                            |
               +-----------------------+                            | (Zero-Knowledge
                               | Secure HTTPS API Calls             |  Local Storage)
                               v                                    v
  +----------------------------------------------------------------------------------+
  |                         NODE.JS / EXPRESS FINANCIAL CORE                         |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  | PDF / CSV Statement    |  | Transaction ML         |  | Cash Flow Forecast |  |
  |  | Reconciliation Engine  |  | Categorizer Service    |  | & Predictive Math  |  |
  |  +-----------+------------+  +-----------+------------+  +---------+----------+  |
  +--------------|---------------------------|-------------------------|-------------+
                 |                           |                         |
                 v                           v                         v
  +----------------------------------------------------------------------------------+
  |                         FINANCIAL PERSISTENCE REPOSITORY                         |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  | Encrypted PostgreSQL   |  | Monthly Budget &       |  | Categorization     |  |
  |  | Transaction Ledger     |  | Savings Goals Cache    |  | Knowledge Base     |  |
  |  +------------------------+  +------------------------+  +--------------------+  |
  +----------------------------------------------------------------------------------+`,
      erd: `
  +-------------------------+            +--------------------------+
  |      USER ACCOUNT       | 1        * |     FINANCIAL ACCOUNT    |
  +-------------------------+------------+--------------------------+
  | - userId: UUID (PK)     |            | - accountId: UUID        |
  | - userEmail: string     |            | - bankName: string       |
  | - monthlyIncome: number |            | - accountType: string    |
  | - savingsTarget: number |            | - currentBalance: number |
  +------------+------------+            +------------+-------------+
               | 1                                    | 1
               |                                      | *
               |                         +------------+-------------+
               |                         |     TRANSACTION RECORD   |
               |                         +--------------------------+
               |                         | - txnId: UUID            |
               |                         | - amount: number         |
               |                         | - merchant: string       |
               |                         | - category: string       |
               |                         | - txnDate: timestamp     |
               |                         +--------------------------+
               | 1
               v *
  +-------------------------+            +--------------------------+
  |      MONTHLY BUDGET     | 1        * |      SAVINGS INSIGHT     |
  +-------------------------+------------+--------------------------+
  | - budgetId: UUID        |            | - insightId: UUID        |
  | - categoryName: string  |            | - recommendationText: str|
  | - allocatedLimit: number|            | - potentialSaving: number|
  | - actualSpent: number   |            | - priority: 'HIGH'|'LOW' |
  +-------------------------+            +--------------------------+`,
      testCases: [
        { id: 'TC-01', req: 'FR-1 (Statement Parse)', scenario: 'User uploads standard multi-page bank PDF statement', exp: 'Parses all 64 transactions with exact debit/credit amounts and dates verified', res: 'PASS' },
        { id: 'TC-02', req: 'FR-2 (Category ML)', scenario: 'Transactions with ambiguous merchant "AMZN MKTP US"', exp: 'Correctly classifies under "Shopping / Retail" with confidence > 0.94', res: 'PASS' },
        { id: 'TC-03', req: 'FR-3 (Cash Flow)', scenario: 'Project expenses 14 days before salary credit date', exp: 'Forecasts potential liquidity deficit 3 days in advance and suggests expense freeze', res: 'PASS' },
        { id: 'TC-04', req: 'FR-4 (Budget Alert)', scenario: 'User dining spend reaches 92% of monthly allocated threshold', exp: 'Displays yellow warning badge and push notification with remaining safe daily allowance', res: 'PASS' },
        { id: 'TC-05', req: 'SEC-01 (Privacy)', scenario: 'User financial statement stored in local browser repository', exp: 'Encrypted via client-derived cryptographic key; server stores zero plaintext bank logs', res: 'PASS' },
        { id: 'TC-06', req: 'PERF-01 (Charts)', scenario: 'Render annual breakdown across 2,400 transaction records', exp: 'Chart.js renders in under 60ms without frame drops or memory leaks', res: 'PASS' },
        { id: 'TC-07', req: 'EXP-01 (Export)', scenario: 'Export monthly expenditure report to PDF and CSV', exp: 'Produces formatted multi-page PDF breakdown with category charts and summary table', res: 'PASS' },
        { id: 'TC-08', req: 'REL-01 (Offline)', scenario: 'Device enters airplane mode during expense logging', exp: 'Logs locally and queues automatic sync on internet reconnection', res: 'PASS' },
        { id: 'TC-09', req: 'CALC-01 (Math)', scenario: 'Total monthly debits subtracted from starting balance + credits', exp: 'Arithmetic balance calculation matches bank final balance with 0.00 margin of error', res: 'PASS' },
        { id: 'TC-10', req: 'UI-01 (Theme)', scenario: 'Toggle dark mode while reviewing financial charts', exp: 'High contrast palettes maintained; labels and legends remain fully legible', res: 'PASS' },
      ],
    };
  }

  // Default / Universal Engineering Capstone Context
  return {
    domainCategory: `${project.domain || 'Computer Science & Software Systems'}`,
    problemContext: `In modern ${project.domain || 'technical applications'}, existing conventional workflows suffer from lack of intelligent automation, high operational friction, and fragmented architectural toolchains. Students and practitioners require an integrated, verifiable engineering system that synthesizes reliable algorithmic processing, responsive visualization, and robust data persistence.`,
    primaryObjective: `To implement '${project.name}' as a production-grade software solution utilizing ${tech}, ensuring high computational throughput, modular clean architecture, and verifiable academic compliance.`,
    modules: [
      { id: 'FR-1', name: 'Input Processing & Schema Validation Subsystem', desc: 'Validates and sanitizes multi-source domain data payloads, enforcing boundary constraints.' },
      { id: 'FR-2', name: 'Core Computational & Business Logic Pipeline', desc: `Executes domain-specific algorithmic transformations adhering to ${tech} best practices.` },
      { id: 'FR-3', name: 'Analytics, State Management & Intelligent Automation', desc: 'Delivers real-time state synchronization, anomaly detection, and automated reporting.' },
      { id: 'FR-4', name: 'Export Engine & Academic Documentation Generator', desc: 'Generates IEEE 830 compliant SRS documentation, technical reports, and deployment artifacts.' },
    ],
    diagram: `
  +----------------------------------------------------------------------------------+
  |                           CLIENT PRESENTATION LAYER                              |
  |  +--------------------+  +--------------------+  +----------------------------+  |
  |  |  Responsive UI     |  |  Interactive Form  |  |  Client-Side State Cache   |  |
  |  |  Component Tree    |  |  Validation Engine |  |  (Preferences & Session)   |  |
  |  +---------+----------+  +---------+----------+  +--------------+-------------+  |
  +------------|-----------------------|----------------------------|----------------+
               |                       |                            |
               +-----------------------+                            | (Direct Client
                               | REST Requests (HTTP/HTTPS)         |  Hydration)
                               v                                    v
  +----------------------------------------------------------------------------------+
  |                             CORE PROCESSING SERVICE                              |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  |  Authentication &      |  |  Business Logic &      |  |  Error Recovery    |  |
  |  |  Request Filter        |  |  Transformation Pipeline|  |  & Fallback Engine |  |
  |  +-----------+------------+  +-----------+------------+  +---------+----------+  |
  +--------------|---------------------------|-------------------------|-------------+
                 |                           |                         |
                 v                           v                         v
  +----------------------------------------------------------------------------------+
  |                        DATA PERSISTENCE & STORAGE TIER                           |
  |  +------------------------+  +------------------------+  +--------------------+  |
  |  | Relational Database    |  | File & Document Cache  |  | External Service   |  |
  |  | (PostgreSQL / SQLite)  |  | (LocalStorage / S3)    |  | APIs (AI/Telemetry)|  |
  |  +------------------------+  +------------------------+  +--------------------+  |
  +----------------------------------------------------------------------------------+`,
    erd: `
  +-------------------------+            +--------------------------+
  |      PROJECT RECORD     | 1        * |      ROADMAP PHASE       |
  +-------------------------+------------+--------------------------+
  | - id: string (UUID)     |            | - id: number             |
  | - name: string          |            | - name: string           |
  | - domain: string        |            | - status: PhaseStatus    |
  | - technologies: string[]|            | - phaseVelocity: number  |
  | - progress: number      |            +------------+-------------+
  | - createdAt: timestamp  |                         | 1
  +------------+------------+                         |
               | 1                                    | *
               |                         +------------+-------------+
               |                         |       MILESTONE TASK     |
               |                         +--------------------------+
               |                         | - taskId: string         |
               |                         | - title: string          |
               |                         | - completed: boolean     |
               |                         +--------------------------+
               | 1
               +-------------------------+ 1
               |                         |
               v *                       v *
  +-------------------------+  +------------------------------------+
  |   ANALYTICAL SESSION    |  |         EVALUATION REPORT          |
  +-------------------------+  +------------------------------------+
  | - sessionId: string     |  | - evalId: string                   |
  | - inputPayload: string  |  | - overallScore: number (0-100)     |
  | - outcome: string       |  | - rubricBreakdown: Record<string>  |
  | - timestamp: Date       |  | - generatedAt: timestamp           |
  +-------------------------+  +------------------------------------+`,
    testCases: [
      { id: 'TC-01', req: 'FR-1 (Validation)', scenario: 'Submit empty or malformed input payload to system entrypoint', exp: 'Rejects with validation error, highlights invalid fields with descriptive error message', res: 'PASS' },
      { id: 'TC-02', req: 'FR-1 (Sanitization)', scenario: 'Submit text containing script injection tags', exp: 'Escapes dangerous characters, safe storage guaranteed without execution', res: 'PASS' },
      { id: 'TC-03', req: 'FR-2 (Transformation)', scenario: 'Standard valid domain input submission', exp: 'Computes expected transformation within target latency benchmark (<500ms)', res: 'PASS' },
      { id: 'TC-04', req: 'FR-2 (Fallback)', scenario: 'Simulate network disconnection during background task execution', exp: 'Seamlessly routes to deterministic offline engine; zero application crash', res: 'PASS' },
      { id: 'TC-05', req: 'FR-3 (Velocity)', scenario: 'Toggle milestone task from incomplete to completed state', exp: 'Aggregated progress percentage recalculates dynamically in real time', res: 'PASS' },
      { id: 'TC-06', req: 'FR-3 (Anomalies)', scenario: 'Submit out-of-boundary domain parameters', exp: 'Flags anomaly with high confidence score and informative advisory message', res: 'PASS' },
      { id: 'TC-07', req: 'FR-4 (SRS Export)', scenario: 'Trigger 10+ page SRS document generation', exp: 'Renders 12 complete IEEE 830 compliant pages with verified layout integrity', res: 'PASS' },
      { id: 'TC-08', req: 'FR-4 (Downloads)', scenario: 'Download as PDF, Word .doc, and Markdown .md formats', exp: 'Produces valid downloadable files without formatting corruption or missing pages', res: 'PASS' },
      { id: 'TC-09', req: 'SEC-01 (Key Security)', scenario: 'Audit client source maps and network headers', exp: 'Zero leakage of server environment variables or private API credentials', res: 'PASS' },
      { id: 'TC-10', req: 'UI-01 (Accessibility)', scenario: 'Test responsive view on mobile (375px) and desktop (1440px)', exp: 'Zero text clipping, WCAG 2.1 AA contrast preserved across all components', res: 'PASS' },
    ],
  };
}

export function generateSRSForProject(
  project?: Project,
  userMetadata?: Partial<DocumentMetadata>
): { metadata: DocumentMetadata; pages: SRSPage[] } {
  // If no project provided, create a default realistic capstone project
  const currentProj: Project = project || {
    id: 'proj-default',
    name: 'AI Medical Symptom Triage Chatbot',
    description: 'A conversational agent for pre-clinical triage that collects patient symptoms, calculates preliminary risk scores, and routes to appropriate emergency or clinic departments.',
    domain: 'Healthcare & Clinical Informatics',
    difficulty: 'Intermediate',
    technologies: ['Python', 'FastAPI', 'React', 'TailwindCSS', 'Gemini API', 'PostgreSQL'],
    status: 'Development',
    progress: 65,
    startDate: '2026-09-01',
    targetDate: '2026-11-30',
    teamSize: '3 Members',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const domainCtx = getDomainContext(currentProj);
  const projTitle = currentProj.name.toUpperCase();
  const projDomain = currentProj.domain || domainCtx.domainCategory;
  const techList = currentProj.technologies && currentProj.technologies.length > 0
    ? currentProj.technologies.join(', ')
    : 'React, Node.js, Express, Python, PostgreSQL, Gemini API';

  // Extract active user account dynamically
  const currentUser = storageService.getCurrentUser();
  const primaryStudentName = userMetadata?.students?.[0]?.name 
    || currentUser?.fullName 
    || "Sridevi Yenni";
  const primaryRollNo = userMetadata?.students?.[0]?.rollNo 
    || currentUser?.studentId 
    || "21A91A0501";
  const userCollege = userMetadata?.institutionName 
    || currentUser?.collegeOrUniversity 
    || "DEPARTMENT OF COMPUTER SCIENCE AND ENGINEERING";
  const userDept = userMetadata?.department 
    || currentUser?.degreeOrBranch 
    || "Department of Computer Science & Engineering";

  const metadata: DocumentMetadata = {
    projectTitle: projTitle,
    projectSubtitle: currentProj.description,
    repoUrl: currentProj.githubUrl || `https://github.com/project-repo/${currentProj.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}.git`,
    documentRef: `SRS-${currentProj.name.substring(0, 4).toUpperCase().replace(/[^A-Z]/g, 'PRJ')}-2026-V1.0`,
    standard: "IEEE Std 830-1998 Recommended Practice for Software Requirements Specifications",
    version: "1.0.0",
    submissionDate: "October 2026",
    academicYear: "2025 - 2026",
    institutionName: userCollege,
    institutionSubtitle: userMetadata?.institutionSubtitle || "AFFILIATED TO JAWAHARLAL NEHRU TECHNOLOGICAL UNIVERSITY (JNTU)",
    department: userDept,
    degree: userMetadata?.degree || "Bachelor of Technology (B.Tech)",
    students: userMetadata?.students || [
      { name: primaryStudentName, rollNo: primaryRollNo, role: "Team Lead & Full-Stack Architect" },
      { name: "Student Collaborator 2", rollNo: "21A91A0502", role: "AI & Algorithmic Specialist" },
      { name: "Student Collaborator 3", rollNo: "21A91A0503", role: "Quality Assurance & Verification" },
    ],
    guideName: userMetadata?.guideName || "Dr. K. V. Raman, M.Tech., Ph.D.",
    guideDesignation: userMetadata?.guideDesignation || "Professor & Head of Department",
    guideDepartment: userMetadata?.guideDepartment || "Department of Computer Science & Engineering",
    hodName: userMetadata?.hodName || "Dr. K. V. Raman, Ph.D.",
    coordinatorName: userMetadata?.coordinatorName || "Dr. S. Lakshmi, M.Tech., Ph.D.",
    ...userMetadata,
  };

  const pages: SRSPage[] = [
    // Page 1: Title & Cover Page
    {
      pageNumber: 1,
      title: "Title & Cover Page",
      headerTitle: "Software Requirements Specification · Cover Sheet",
      sections: [{ customComponent: "coverPage" }],
    },

    // Page 2: Bonafide Certificate & Formal Approval
    {
      pageNumber: 2,
      title: "Certificates & Formal Approval Sheet",
      headerTitle: "Bonafide Certificate & Formal Approval Sheet",
      sections: [{ customComponent: "certificatePage" }],
    },

    // Page 3: Executive Summary & Table of Contents
    {
      pageNumber: 3,
      title: "Executive Summary & Table of Contents",
      headerTitle: "Executive Abstract & Table of Contents",
      sections: [
        {
          heading: "Executive Summary",
          paragraphs: [
            `This Software Requirements Specification (SRS) establishes the formal operational, behavioural, algorithmic, and interface requirements for '${currentProj.name}'. Conceived in the specialized domain of ${projDomain}, the platform leverages a modern computing architecture (${techList}) to engineer a high-impact solution for real-world capstone engineering evaluation.`,
            domainCtx.primaryObjective,
            `The document delineates functional specifications, external interfaces, performance guarantees, data model entity schemas, and rigorous verification test cases to provide a complete engineering contract for academic review boards and viva voce evaluators.`
          ],
          callout: {
            type: "important",
            title: "IEEE 830-1998 Compliance Declaration",
            text: "This document adheres strictly to IEEE Std 830-1998 standards, utilizing RFC 2119 requirement keyword semantics ('SHALL', 'MUST', 'SHOULD', 'MAY') and ISO/IEC/IEEE 29148:2018 systems engineering process specifications."
          }
        },
        {
          heading: "Table of Contents & Page Reference Index",
          table: {
            headers: ["Section ID", "Document Section & Sub-Modules", "Target Page", "IEEE Standard Reference"],
            rows: [
              ["Cover", "Official Title Page, Institutional Affiliation & Authorship", "Page 1", "IEEE Std 830 Clause 4"],
              ["Sign-off", "Bonafide Certificate, Approval Sheet & Declarations", "Page 2", "Academic Accreditation Clause"],
              ["Abstract", "Executive Summary, Conventions & Table of Contents", "Page 3", "IEEE Std 830 Clause 4.1"],
              ["Section 1", "Introduction, Purpose, Scope, Problem Statement & References", "Page 4", "IEEE Std 830 Section 1"],
              ["Section 2", "Overall Description, System Architecture & User Classes", "Page 5", "IEEE Std 830 Section 2"],
              ["Section 3.1", "Functional Requirements: Ingestion & Core Subsystems", "Page 6", "IEEE Std 830 Section 3.1"],
              ["Section 3.2", "Functional Requirements: Analytics, Business Logic & Reports", "Page 7", "IEEE Std 830 Section 3.2"],
              ["Section 4", "External Interface Requirements: UI/UX, Hardware & APIs", "Page 8", "IEEE Std 830 Section 4"],
              ["Section 5", "Non-Functional Requirements: Latency, Security & Reliability", "Page 9", "IEEE Std 830 Section 5"],
              ["Section 6", "Data Models, State Schemas, DFDs & Entity Relationships", "Page 10", "IEEE Std 830 Section 6"],
              ["Section 7", "System Verification, 10 Test Cases & Traceability Matrix (RTM)", "Page 11", "IEEE Std 830 Section 7"],
              ["Section 8", "Deployment Guide, Viva Rubrics, Prompts & Document History", "Page 12", "IEEE Std 830 Appendices"]
            ]
          }
        }
      ]
    },

    // Page 4: Section 1 - Introduction & Problem Statement
    {
      pageNumber: 4,
      title: "1. Introduction, Purpose & Problem Statement",
      headerTitle: "Section 1 · Introduction & Project Scope",
      sections: [
        {
          heading: "1.1 Purpose of the Specification",
          paragraphs: [
            `The purpose of this Software Requirements Specification (SRS) is to establish an unambiguous, complete, and verifiable contractual description of the software features, data behaviors, and constraints for '${currentProj.name}'.`,
            `This specification serves as the foundational reference for undergraduate engineering students, departmental faculty supervisors, university review committees, and external viva voce examination boards.`
          ]
        },
        {
          heading: "1.2 Scope of the System",
          paragraphs: [
            `'${currentProj.name}' is an engineering software application designed for ${projDomain}. The system is built utilizing ${techList}.`,
            `Key boundaries of the software include client-side user experience, high-availability server controller routing, algorithmic computation pipelines, persistent data storage, and automated reporting.`
          ]
        },
        {
          heading: "1.3 Problem Definition & Engineering Motivation",
          paragraphs: [
            domainCtx.problemContext,
            `The implementation of '${currentProj.name}' addresses these challenges by substituting ad-hoc manual procedures with verifiable, algorithmically enforced software engineering pipelines.`
          ]
        },
        {
          heading: "1.4 References & Applicable Standards",
          bullets: [
            "IEEE Std 830-1998: IEEE Recommended Practice for Software Requirements Specifications.",
            "ISO/IEC/IEEE 29148:2018: Systems and software engineering — Life cycle processes.",
            "RFC 2119: Key words for use in RFCs to Indicate Requirement Levels.",
            `Technical standards and documentation for ${techList}.`
          ]
        }
      ]
    },

    // Page 5: Section 2 - Overall Description & Architecture
    {
      pageNumber: 5,
      title: "2. Overall Description & System Perspective",
      headerTitle: "Section 2 · Overall Description & System Architecture",
      sections: [
        {
          heading: "2.1 Product Perspective & Architectural Paradigm",
          paragraphs: [
            `'${currentProj.name}' is architected as an autonomous multi-tier client-server application. It decouples high-performance presentation layers from backend business logic and persistence repositories, facilitating continuous integration and zero-downtime deployment.`
          ]
        },
        {
          heading: "2.2 High-Level Architecture Block Diagram",
          diagram: {
            title: `Figure 2.1: ${currentProj.name} System Architecture Block Diagram`,
            type: "architecture",
            caption: `Multi-tier structural block diagram illustrating Presentation, Processing, and Data Layers for ${currentProj.name}.`,
            asciiArt: domainCtx.diagram,
          }
        },
        {
          heading: "2.3 User Classes and Operational Personas",
          table: {
            headers: ["Persona Class", "Primary Responsibility", "Technical Skill", "System Privilege Level"],
            rows: [
              ["Primary End User", "Executes day-to-day domain workflows, inputs parameters, reviews outputs", "Basic to Intermediate", "User Role (Read/Write Own Records)"],
              ["Faculty Guide / Supervisor", "Audits milestone completion, reviews analytics, verifies SRS compliance", "Expert", "Reviewer Role (Audit & Endorse)"],
              ["Project Coordinator / Dean", "Monitors cohort progress velocity, schedules viva defenses", "Expert", "Department Administrator Role"],
              ["External Viva Voce Examiner", "Cross-examines candidate, audits code quality and IEEE SRS adherence", "Subject Matter Expert", "Formal Evaluation & Grading Role"]
            ]
          }
        },
        {
          heading: "2.4 Assumptions, Dependencies & Constraints",
          bullets: [
            `Framework Dependencies: Built upon ${techList}.`,
            "Browser Standards: Evergreen web browsers with JavaScript ES2022+ enabled.",
            "Security Constraints: API credentials and private access keys must remain isolated server-side."
          ]
        }
      ]
    },

    // Page 6: Section 3.1 - Functional Requirements (Part 1)
    {
      pageNumber: 6,
      title: "3. Functional Requirements: Ingestion & SDLC",
      headerTitle: "Section 3 · Functional Requirements (Part 1)",
      sections: [
        {
          heading: `3.1 Module 1: ${domainCtx.modules[0]?.name || 'Data Ingestion'}`,
          paragraphs: [
            domainCtx.modules[0]?.desc || 'Manages the structured ingestion of input records, validating schema boundaries.'
          ],
          table: {
            headers: ["Req ID", "Requirement Description", "Input Payload", "Expected System Action", "Priority"],
            rows: [
              ["FR-1.1", "Schema Boundary Validation", "User domain input parameters", "Validates format; rejects malformed inputs with HTTP 400", "HIGH"],
              ["FR-1.2", "Input Sanitization & Escaping", "Raw form text & inputs", "Strips dangerous HTML/script injection tags", "HIGH"],
              ["FR-1.3", "Session State Hydration", "Local user actions", "Preserves uncommitted changes in client cache", "MEDIUM"],
              ["FR-1.4", "Batch Verification Engine", "Structured JSON / CSV array", "Parses and verifies multiple records simultaneously", "MEDIUM"]
            ]
          }
        },
        {
          heading: `3.2 Module 2: ${domainCtx.modules[1]?.name || 'Core Processing'}`,
          paragraphs: [
            domainCtx.modules[1]?.desc || 'Encapsulates the core algorithmic transformations and state machines.'
          ],
          table: {
            headers: ["Phase ID", "Development Phase", "Deliverables", "Viva Weight"],
            rows: [
              ["Phase 1", "Requirements Formulation", "Problem statement, IEEE SRS draft", "15%"],
              ["Phase 2", "UI/UX & Wireframing", "Component tree, responsive layout", "15%"],
              ["Phase 3", "Database & Data Models", "Entity relationships, migrations", "20%"],
              ["Phase 4", "Core Logic & APIs", "Controllers, business transformations", "25%"],
              ["Phase 5", "Verification & Testing", "Unit test cases, viva rehearsal", "25%"]
            ]
          }
        }
      ]
    },

    // Page 7: Section 3.2 - Functional Requirements (Part 2)
    {
      pageNumber: 7,
      title: "3. Functional Requirements: Logic & Reporting",
      headerTitle: "Section 3 · Functional Requirements (Part 2)",
      sections: [
        {
          heading: `3.3 Module 3: ${domainCtx.modules[2]?.name || 'Analytics & Automation'}`,
          paragraphs: [
            domainCtx.modules[2]?.desc || 'Applies analytical algorithms, detects anomalies, and generates recommendations.'
          ],
          table: {
            headers: ["Mode ID", "Operational Mode", "Objective", "Key Output Metric"],
            rows: [
              ["FR-3.1", "Real-time Diagnostics", "Scans domain parameters for anomalies", "Confidence rating (0-100%)"],
              ["FR-3.2", "Root Cause Analysis", "Deconstructs failure modes", "Step-by-step diagnostic breakdown"],
              ["FR-3.3", "Prescriptive Guidance", "Recommends actionable mitigations", "Prioritized task checklist"],
              ["FR-3.4", "Comparative Benchmarking", "Compares with baseline standards", "Standardized variance report"]
            ]
          }
        },
        {
          heading: `3.4 Module 4: ${domainCtx.modules[3]?.name || 'Reporting & Documentation'}`,
          bullets: [
            `FR-4.1: The system SHALL generate IEEE 830-1998 compliant SRS documentation for '${currentProj.name}' with a minimum of 10 pages.`,
            `FR-4.2: The system SHALL provide 1-click downloads in PDF (.pdf), Word (.doc), Markdown (.md), and Print-to-PDF formats.`,
            `FR-4.3: The system SHALL enable real-time user customization of candidate authors, guide credentials, and university department.`
          ]
        }
      ]
    },

    // Page 8: Section 4 - External Interface Requirements
    {
      pageNumber: 8,
      title: "4. External Interface Requirements",
      headerTitle: "Section 4 · External Interface Specifications",
      sections: [
        {
          heading: "4.1 User Interfaces & Visual Design System",
          paragraphs: [
            `The user interface conforms to WCAG 2.1 AA accessibility guidelines, offering high-contrast typography, keyboard navigation, and responsive scaling across mobile, tablet, and desktop viewports.`
          ]
        },
        {
          heading: "4.2 Hardware & Operational Interfaces",
          table: {
            headers: ["Subsystem", "Minimum Client Specification", "Recommended Client", "Server Specification"],
            rows: [
              ["Processor", "Dual-Core 2.0 GHz Intel/AMD/ARM", "Quad-Core 2.5 GHz or Apple Silicon", "1 vCPU / Micro-instance (Cloud Run)"],
              ["Memory (RAM)", "4 GB RAM", "8 GB RAM or higher", "512 MB to 1 GB RAM"],
              ["Display", "1280 x 720 px (HD)", "1920 x 1080 px (FHD)", "Headless Server Environment"],
              ["Network", "512 kbps broadband", "2 Mbps low-latency connection", "High-speed HTTPS connectivity"]
            ]
          }
        },
        {
          heading: "4.3 Software & API Interface Specifications",
          bullets: [
            `Frontend Stack: React 19, TypeScript, Tailwind CSS, Lucide Icons.`,
            `Backend Stack: Node.js 20+, Express 4.21 / FastAPI, RESTful API controllers.`,
            `Communication Protocol: JSON over HTTP/1.1 and HTTP/2 with TLS 1.3 encryption.`
          ]
        }
      ]
    },

    // Page 9: Section 5 - Non-Functional Requirements & Security
    {
      pageNumber: 9,
      title: "5. Non-Functional Requirements & Security",
      headerTitle: "Section 5 · Non-Functional Requirements & Security",
      sections: [
        {
          heading: "5.1 Performance Latency Benchmarks",
          table: {
            headers: ["Metric ID", "System Operation", "Target Latency", "Acceptance Threshold"],
            rows: [
              ["PERF-01", "Client-side initial dashboard load", "< 300 ms", "< 1000 ms on 3G connections"],
              ["PERF-02", "Interactive view transitions", "< 16 ms (60 FPS)", "Cumulative Layout Shift (CLS) < 0.05"],
              ["PERF-03", "Analytical computation round-trip", "< 1200 ms", "< 3000 ms under standard loads"],
              ["PERF-04", "Offline fallback execution", "< 10 ms", "Instantaneous, non-blocking UI response"],
              ["PERF-05", "Multi-Page PDF & Word Document Assembly", "< 800 ms", "< 2000 ms for full 12-page document"]
            ]
          }
        },
        {
          heading: "5.2 System Reliability & Zero-Crash Architecture",
          paragraphs: [
            `The system enforces an uncompromising 'Zero-Crash Architecture':`,
            `1. Graceful Offline Degradation: In the event of network disruption or external API limits, the system seamlessly activates deterministic offline rule engines.`,
            `2. Local State Preservation: All user edits and active records are persisted in local storage with automatic debounce.`
          ]
        },
        {
          heading: "5.3 Security & Credential Protection",
          paragraphs: [
            `SEC-01: Under no circumstance SHALL sensitive API keys or credentials be leaked into client-side bundles.`,
            `SEC-02: All input payloads SHALL be validated against strict schemas to prevent injection attacks.`
          ]
        }
      ]
    },

    // Page 10: Section 6 - Data Models & Diagrams
    {
      pageNumber: 10,
      title: "6. Data Models, State Schemas & Diagrams",
      headerTitle: "Section 6 · Data Models & Architectural Diagrams",
      sections: [
        {
          heading: "6.1 State Schema & Entity Specifications",
          diagram: {
            title: `Figure 6.1: ${currentProj.name} Entity-Relationship Schema`,
            type: "erd",
            caption: `Relational schema mapping entities, analytical sessions, and reports for ${currentProj.name}.`,
            asciiArt: domainCtx.erd,
          }
        }
      ]
    },

    // Page 11: Section 7 - Verification & Test Cases
    {
      pageNumber: 11,
      title: "7. Verification, Test Cases & Traceability",
      headerTitle: "Section 7 · Verification & Test Cases",
      sections: [
        {
          heading: "7.1 Verification Strategy",
          paragraphs: [
            `The '${currentProj.name}' system underwent formal verification across Unit Testing, Integration Testing, and Academic Viva Voce dry-runs.`
          ]
        },
        {
          heading: "7.2 Comprehensive Test Cases (TC-01 through TC-10)",
          table: {
            headers: ["Test ID", "Requirement Tested", "Test Scenario & Inputs", "Expected Result", "Status"],
            rows: domainCtx.testCases.map((tc) => [tc.id, tc.req, tc.scenario, tc.exp, tc.res]),
          }
        }
      ]
    },

    // Page 12: Section 8 - Deployment & Appendices
    {
      pageNumber: 12,
      title: "8. Deployment, Appendices & Document History",
      headerTitle: "Section 8 · Deployment, Appendices & Sign-off",
      sections: [
        {
          heading: "8.1 Production Deployment Guidelines",
          paragraphs: [
            `The application supports both local execution and cloud deployment:`,
            `1. Local Installation: Clone repository (${metadata.repoUrl}), install dependencies via 'npm install', supply environment variables, and run 'npm run dev'.`,
            `2. Production Cloud Deployment: Deploy via Vercel or Cloud Run container with environment secrets properly configured.`
          ]
        },
        {
          heading: "8.2 Appendix A: Glossary of Academic & Technical Terms",
          bullets: [
            "SRS: Software Requirements Specification (IEEE Std 830-1998 compliant document).",
            "SDLC: Software Development Life Cycle (8 standardized engineering phases).",
            "RTM: Requirements Traceability Matrix linking requirements to test cases.",
            "WCAG: Web Content Accessibility Guidelines for responsive and accessible UI."
          ]
        },
        {
          heading: "8.3 Appendix B: Academic Viva Voce Grading Rubric (100% Breakdown)",
          table: {
            headers: ["Category", "Dimension", "Weight", "Evaluator Focus"],
            rows: [
              ["Technical", "Core Functionality & Architecture", "25%", "Verification of working demo and clean modular code"],
              ["Engineering", "SDLC Tracking & Verification", "25%", "Review of test cases, edge condition handling, and RTM"],
              ["Documentation", "SRS Quality & IEEE Compliance", "25%", "Completeness of 10+ page SRS, diagrams, and contracts"],
              ["Presentation", "Viva Voce Defense & Questioning", "25%", "Ability to justify design decisions and algorithms"]
            ]
          }
        },
        {
          heading: "8.4 Appendix C: Formal Revision History",
          table: {
            headers: ["Version", "Release Date", "Primary Changes", "Author", "Approved By"],
            rows: [
              ["v0.1.0", "August 2025", "Initial Requirements Draft & Feasibility Study", primaryStudentName, "Dr. K. V. Raman"],
              ["v0.8.0", "January 2026", "SDLC Architecture & Test Cases Integrated", primaryStudentName, "Dr. S. Lakshmi"],
              ["v1.0.0", "October 2026", "Complete 12-Page IEEE 830 Release with Multi-Format Download", primaryStudentName, "Project Review Board"]
            ]
          }
        }
      ]
    }
  ];

  return { metadata, pages };
}
