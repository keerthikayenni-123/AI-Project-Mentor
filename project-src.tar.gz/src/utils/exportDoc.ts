import { DocumentMetadata, SRSPage } from '../types/srs';

export function generateWordDocument(metadata: DocumentMetadata, pages: SRSPage[]): void {
  let docContent = `
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
  <meta charset="utf-8">
  <title>${metadata.projectTitle} - Software Requirements Specification</title>
  <!--[if gte mso 9]>
  <xml>
    <w:WordDocument>
      <w:View>Print</w:View>
      <w:Zoom>100</w:Zoom>
      <w:DoNotOptimizeForBrowser/>
    </w:WordDocument>
  </xml>
  <![endif]-->
  <style>
    @page {
      size: 210mm 297mm;
      margin: 20mm 20mm 20mm 20mm;
      mso-header-margin: 10mm;
      mso-footer-margin: 10mm;
    }
    body {
      font-family: 'Times New Roman', Times, serif;
      font-size: 11pt;
      line-height: 1.45;
      color: #1e293b;
    }
    h1 {
      font-family: 'Times New Roman', Times, serif;
      font-size: 18pt;
      font-weight: bold;
      color: #0f172a;
      text-align: center;
      margin-top: 15pt;
      margin-bottom: 8pt;
    }
    h2 {
      font-family: 'Times New Roman', Times, serif;
      font-size: 14pt;
      font-weight: bold;
      color: #1e3a8a;
      border-bottom: 1pt solid #cbd5e1;
      padding-bottom: 3pt;
      margin-top: 14pt;
      margin-bottom: 6pt;
    }
    h3 {
      font-family: 'Times New Roman', Times, serif;
      font-size: 12pt;
      font-weight: bold;
      color: #0f172a;
      margin-top: 10pt;
      margin-bottom: 4pt;
    }
    p {
      margin-top: 0;
      margin-bottom: 6pt;
      text-align: justify;
    }
    .page-break {
      page-break-before: always;
      mso-special-character: line-break;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 8pt;
      margin-bottom: 12pt;
      font-size: 10pt;
    }
    th {
      background-color: #f1f5f9;
      border: 1pt solid #94a3b8;
      padding: 6pt 8pt;
      font-weight: bold;
      text-align: left;
    }
    td {
      border: 1pt solid #cbd5e1;
      padding: 5pt 8pt;
    }
    .callout {
      background-color: #f8fafc;
      border-left: 3pt solid #2563eb;
      padding: 8pt 12pt;
      margin: 8pt 0;
      font-style: italic;
    }
    pre {
      font-family: 'Courier New', Courier, monospace;
      font-size: 8.5pt;
      background-color: #f8fafc;
      border: 1pt solid #e2e8f0;
      padding: 8pt;
      white-space: pre-wrap;
    }
    .text-center { text-align: center; }
    .header-box {
      border: 2pt double #1e293b;
      padding: 20pt;
      text-align: center;
      margin-bottom: 30pt;
    }
    .meta-box {
      background-color: #f8fafc;
      border: 1pt solid #cbd5e1;
      padding: 12pt;
      margin: 15pt 0;
    }
  </style>
</head>
<body>
`;

  pages.forEach((page, index) => {
    if (index > 0) {
      docContent += `<div class="page-break"></div>`;
    }

    if (page.pageNumber === 1) {
      // Cover Page
      docContent += `
        <div class="header-box">
          <h2 style="border:none; margin:0; font-size:16pt;">${metadata.institutionName}</h2>
          <p style="margin:2pt 0; font-style:italic; font-size:10pt; color:#475569;">${metadata.institutionSubtitle}</p>
          <p style="margin:2pt 0; font-weight:bold;">${metadata.department}</p>
          <hr style="border:0; border-top:1pt solid #94a3b8; margin:15pt 0;" />
          
          <h3 style="color:#2563eb; letter-spacing:1pt; margin:8pt 0;">SOFTWARE REQUIREMENTS SPECIFICATION (SRS)</h3>
          <p style="font-size:9pt; color:#64748b;">Compliant with ${metadata.standard}</p>
          <p style="font-size:9pt; color:#64748b;">Ref: ${metadata.documentRef} | Version ${metadata.version}</p>
          
          <h1 style="font-size:22pt; margin:20pt 0 6pt 0;">${metadata.projectTitle}</h1>
          <p style="font-size:12pt; font-style:italic; color:#334155; margin-bottom:15pt;">${metadata.projectSubtitle}</p>
          <p style="font-family:monospace; font-size:9pt; color:#1e40af;">Repository: ${metadata.repoUrl}</p>
          
          <p style="margin-top:25pt;">Submitted in partial fulfillment of the academic requirements for the degree of</p>
          <p style="font-size:13pt; font-weight:bold; margin-top:2pt;">${metadata.degree}</p>
          
          <div class="meta-box" style="text-align:left; margin-top:25pt;">
            <table style="border:none; margin:0;">
              <tr>
                <td style="border:none; vertical-align:top; width:50%;">
                  <strong>SUBMITTED BY:</strong><br/>
                  ${metadata.students.map(s => `• <strong>${s.name}</strong> (Roll: ${s.rollNo})<br/>&nbsp;&nbsp;<em>${s.role || ''}</em><br/>`).join('')}
                </td>
                <td style="border:none; vertical-align:top; width:50%;">
                  <strong>UNDER THE GUIDANCE OF:</strong><br/>
                  <strong>${metadata.guideName}</strong><br/>
                  ${metadata.guideDesignation}<br/>
                  ${metadata.guideDepartment}
                </td>
              </tr>
            </table>
          </div>
          
          <p style="margin-top:20pt; font-weight:bold;">ACADEMIC YEAR: ${metadata.academicYear}</p>
          <p style="font-size:9.5pt; color:#64748b;">Submission Date: ${metadata.submissionDate}</p>
        </div>
      `;
      return;
    }

    if (page.sections[0]?.customComponent === 'certificatePage') {
      docContent += `
        <h1 style="margin-bottom:15pt;">BONAFIDE CERTIFICATE</h1>
        <p style="font-size:11pt; line-height:1.6;">
          This is to certify that this Software Requirements Specification entitled 
          <strong>"${metadata.projectTitle}: ${metadata.projectSubtitle}"</strong> is a bonafide record of 
          technical requirements engineering work carried out by 
          <strong>${metadata.students.map(s => `${s.name} (${s.rollNo})`).join(', ')}</strong> 
          under my supervision and guidance in partial fulfillment of the requirements for the award of the degree of 
          <strong>${metadata.degree}</strong> in Computer Science and Engineering during the academic year 
          <strong>${metadata.academicYear}</strong>.
        </p>

        <h3 style="margin-top:20pt;">DECLARATION OF ORIGINALITY</h3>
        <p>
          We hereby declare that the specifications, architectures, algorithms, and interface designs contained 
          within this document are original works conceived for the AI Project Mentor platform. We acknowledge adherence to academic honesty policies.
        </p>

        <h3 style="margin-top:25pt;">FORMAL APPROVAL & SIGN-OFF</h3>
        <table>
          <tr>
            <th style="width:33%;">INTERNAL GUIDE</th>
            <th style="width:33%;">PROJECT COORDINATOR</th>
            <th style="width:33%;">HEAD OF DEPARTMENT</th>
          </tr>
          <tr style="height:70pt;">
            <td>
              <strong>${metadata.guideName}</strong><br/>
              ${metadata.guideDesignation}<br/><br/>
              Signature: ________________
            </td>
            <td>
              <strong>${metadata.coordinatorName}</strong><br/>
              Associate Professor<br/><br/>
              Signature: ________________
            </td>
            <td>
              <strong>${metadata.hodName}</strong><br/>
              Senior Professor & HOD<br/><br/>
              Signature: ________________
            </td>
          </tr>
        </table>

        <div style="border:1pt solid #94a3b8; padding:10pt; margin-top:20pt; background-color:#f8fafc;">
          <strong>EXTERNAL VIVA VOCE EXAMINER ENDORSEMENT</strong><br/>
          <p style="margin-top:4pt;">External Examiner Name & Institute: __________________________________________________</p>
          <p>Recommendation: [ &nbsp; ] Approved &nbsp;&nbsp;&nbsp; [ &nbsp; ] Approved with notes &nbsp;&nbsp;&nbsp; [ &nbsp; ] Resubmit</p>
          <p>Examiner Signature with Institutional Seal: ________________________ &nbsp;&nbsp; Date: ____________</p>
        </div>
      `;
      return;
    }

    docContent += `<h2>${page.title}</h2>`;

    page.sections.forEach((sec) => {
      if (sec.heading) {
        docContent += `<h3>${sec.heading}</h3>`;
      }
      if (sec.subheading) {
        docContent += `<h4 style="color:#1e3a8a; margin:4pt 0;">${sec.subheading}</h4>`;
      }
      if (sec.paragraphs) {
        sec.paragraphs.forEach((p) => {
          docContent += `<p>${p}</p>`;
        });
      }
      if (sec.bullets) {
        docContent += `<ul>`;
        sec.bullets.forEach((b) => {
          docContent += `<li>${b}</li>`;
        });
        docContent += `</ul>`;
      }
      if (sec.callout) {
        docContent += `
          <div class="callout">
            ${sec.callout.title ? `<strong>${sec.callout.title}:</strong> ` : ''}
            ${sec.callout.text}
          </div>
        `;
      }
      if (sec.table) {
        docContent += `<table><thead><tr>`;
        sec.table.headers.forEach((h) => {
          docContent += `<th>${h}</th>`;
        });
        docContent += `</tr></thead><tbody>`;
        sec.table.rows.forEach((r) => {
          docContent += `<tr>`;
          r.forEach((c) => {
            docContent += `<td>${c}</td>`;
          });
          docContent += `</tr>`;
        });
        docContent += `</tbody></table>`;
      }
      if (sec.diagram && sec.diagram.asciiArt) {
        docContent += `
          <p style="font-weight:bold; margin-top:8pt;">${sec.diagram.title}</p>
          <pre>${sec.diagram.asciiArt}</pre>
          <p style="font-size:9pt; font-style:italic; color:#64748b;">${sec.diagram.caption}</p>
        `;
      }
    });
  });

  docContent += `
</body>
</html>
`;

  const blob = new Blob(['\ufeff' + docContent], {
    type: 'application/msword;charset=utf-8',
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AI-Project-Mentor-SRS-IEEE830-${metadata.version}.doc`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
