import { DocumentMetadata, SRSPage } from '../types/srs';

export function generateMarkdownDocument(metadata: DocumentMetadata, pages: SRSPage[]): void {
  let md = `# ${metadata.projectTitle}\n`;
  md += `## ${metadata.projectSubtitle}\n\n`;
  md += `**Document:** Software Requirements Specification (SRS)\n`;
  md += `**Standard:** ${metadata.standard}\n`;
  md += `**Document Ref:** ${metadata.documentRef} | **Version:** ${metadata.version}\n`;
  md += `**Repository:** [${metadata.repoUrl}](${metadata.repoUrl})\n`;
  md += `**Institution:** ${metadata.institutionName} (${metadata.institutionSubtitle})\n`;
  md += `**Department:** ${metadata.department} | **Degree:** ${metadata.degree}\n`;
  md += `**Academic Year:** ${metadata.academicYear} | **Submission Date:** ${metadata.submissionDate}\n\n`;

  md += `### Project Authors\n`;
  metadata.students.forEach((s) => {
    md += `- **${s.name}** (Roll No: \`${s.rollNo}\`) ${s.role ? `— *${s.role}*` : ''}\n`;
  });
  md += `\n**Project Guide:** ${metadata.guideName}, ${metadata.guideDesignation}, ${metadata.guideDepartment}\n\n`;
  md += `---\n\n`;

  pages.forEach((page) => {
    if (page.pageNumber === 1) return; // already represented above

    md += `\n# Page ${page.pageNumber}: ${page.title}\n\n`;

    page.sections.forEach((sec) => {
      if (sec.heading) {
        md += `## ${sec.heading}\n\n`;
      }
      if (sec.subheading) {
        md += `### ${sec.subheading}\n\n`;
      }
      if (sec.paragraphs) {
        sec.paragraphs.forEach((p) => {
          md += `${p}\n\n`;
        });
      }
      if (sec.bullets) {
        sec.bullets.forEach((b) => {
          md += `- ${b}\n`;
        });
        md += `\n`;
      }
      if (sec.callout) {
        md += `> **${sec.callout.title || 'Note'}:** ${sec.callout.text}\n\n`;
      }
      if (sec.table) {
        md += `| ${sec.table.headers.join(' | ')} |\n`;
        md += `| ${sec.table.headers.map(() => '---').join(' | ')} |\n`;
        sec.table.rows.forEach((r) => {
          md += `| ${r.map((c) => c.replace(/\|/g, '\\|')).join(' | ')} |\n`;
        });
        md += `\n`;
      }
      if (sec.diagram && sec.diagram.asciiArt) {
        md += `**${sec.diagram.title}**\n\n`;
        md += `\`\`\`text\n${sec.diagram.asciiArt}\n\`\`\`\n\n`;
        md += `*${sec.diagram.caption}*\n\n`;
      }
    });

    md += `---\n`;
  });

  const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AI-Project-Mentor-SRS-${metadata.version}.md`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function generateJsonSpecification(metadata: DocumentMetadata, pages: SRSPage[]): void {
  const jsonString = JSON.stringify({ metadata, pages }, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `AI-Project-Mentor-SRS-Spec-${metadata.version}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
