import { jsPDF } from 'jspdf';
import { DocumentMetadata, SRSPage } from '../types/srs';

export function generatePdfDocument(metadata: DocumentMetadata, pages: SRSPage[]): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;

  pages.forEach((page, index) => {
    if (index > 0) {
      doc.addPage();
    }

    // Cover page styling
    if (page.pageNumber === 1) {
      // Outer border frame
      doc.setDrawColor(30, 41, 59);
      doc.setLineWidth(0.8);
      doc.rect(12, 12, pageWidth - 24, pageHeight - 24);

      doc.setLineWidth(0.3);
      doc.rect(14, 14, pageWidth - 28, pageHeight - 28);

      // Header Institution
      doc.setFont('times', 'bold');
      doc.setFontSize(14);
      doc.setTextColor(15, 23, 42);
      doc.text(metadata.institutionName, pageWidth / 2, 28, { align: 'center' });

      doc.setFont('times', 'italic');
      doc.setFontSize(10);
      doc.setTextColor(71, 85, 105);
      doc.text(metadata.institutionSubtitle, pageWidth / 2, 34, { align: 'center' });

      doc.setFont('times', 'normal');
      doc.setFontSize(11);
      doc.setTextColor(30, 41, 59);
      doc.text(metadata.department, pageWidth / 2, 40, { align: 'center' });

      // Dividing rule
      doc.setDrawColor(203, 213, 225);
      doc.line(margin + 10, 46, pageWidth - margin - 10, 46);

      // Document Type
      doc.setFont('times', 'bold');
      doc.setFontSize(13);
      doc.setTextColor(37, 99, 235);
      doc.text("SOFTWARE REQUIREMENTS SPECIFICATION (SRS)", pageWidth / 2, 60, { align: 'center' });

      doc.setFont('times', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139);
      doc.text("Compliant with " + metadata.standard, pageWidth / 2, 66, { align: 'center' });
      doc.text("Document Reference: " + metadata.documentRef + " | Version: " + metadata.version, pageWidth / 2, 71, { align: 'center' });

      // Project Title
      doc.setFont('times', 'bold');
      doc.setFontSize(22);
      doc.setTextColor(15, 23, 42);
      doc.text(metadata.projectTitle, pageWidth / 2, 90, { align: 'center' });

      doc.setFont('times', 'italic');
      doc.setFontSize(11);
      doc.setTextColor(71, 85, 105);
      const subtitleLines = doc.splitTextToSize(metadata.projectSubtitle, contentWidth - 10);
      doc.text(subtitleLines, pageWidth / 2, 100, { align: 'center' });

      // GitHub Repo Link
      doc.setFont('courier', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(30, 58, 138);
      doc.text("Repository: " + metadata.repoUrl, pageWidth / 2, 115, { align: 'center' });

      // Degree Award Statement
      doc.setFont('times', 'normal');
      doc.setFontSize(11);
      doc.setTextColor(51, 65, 85);
      doc.text("A Project Requirements Specification submitted in partial fulfillment", pageWidth / 2, 140, { align: 'center' });
      doc.text("of the requirements for the award of the degree of", pageWidth / 2, 146, { align: 'center' });
      
      doc.setFont('times', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42);
      doc.text(metadata.degree, pageWidth / 2, 153, { align: 'center' });

      // Student and Guide table
      const infoBoxY = 175;
      doc.setDrawColor(226, 232, 240);
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(margin, infoBoxY, contentWidth, 70, 3, 3, 'FD');

      // Left column: Submitted by
      doc.setFont('times', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("SUBMITTED BY:", margin + 8, infoBoxY + 12);

      let studentY = infoBoxY + 20;
      metadata.students.forEach((student) => {
        doc.setFont('times', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(30, 41, 59);
        doc.text(student.name, margin + 8, studentY);
        doc.setFont('times', 'normal');
        doc.setTextColor(100, 116, 139);
        doc.text(`Roll No: ${student.rollNo}${student.role ? ` (${student.role})` : ''}`, margin + 8, studentY + 5);
        studentY += 12;
      });

      // Right column: Guided by
      const rightColX = margin + contentWidth / 2 + 5;
      doc.setFont('times', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("UNDER THE GUIDANCE OF:", rightColX, infoBoxY + 12);

      doc.setFont('times', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      doc.text(metadata.guideName, rightColX, infoBoxY + 20);

      doc.setFont('times', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(71, 85, 105);
      doc.text(metadata.guideDesignation, rightColX, infoBoxY + 26);
      doc.text(metadata.guideDepartment, rightColX, infoBoxY + 32);

      // Bottom footer on cover
      doc.setFont('times', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(30, 41, 59);
      doc.text(`ACADEMIC YEAR: ${metadata.academicYear}`, pageWidth / 2, 260, { align: 'center' });
      doc.setFont('times', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139);
      doc.text(`Submitted on: ${metadata.submissionDate}`, pageWidth / 2, 266, { align: 'center' });

      return;
    }

    // Standard Page Header
    doc.setFont('times', 'italic');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(metadata.projectTitle + " · Software Requirements Specification (IEEE 830)", margin, 12);
    doc.text("Doc Ref: " + metadata.documentRef, pageWidth - margin, 12, { align: 'right' });

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.4);
    doc.line(margin, 14, pageWidth - margin, 14);

    // Standard Page Footer
    doc.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);
    doc.setFont('times', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text("Confidential & Academic Bonafide Record · Department of CSE", margin, pageHeight - 10);
    doc.setFont('times', 'bold');
    doc.text(`Page ${page.pageNumber} of ${pages.length}`, pageWidth - margin, pageHeight - 10, { align: 'right' });

    let currentY = 22;

    // Page Title
    doc.setFont('times', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(15, 23, 42);
    doc.text(page.title, margin, currentY);
    currentY += 8;

    // Check custom components
    if (page.sections[0]?.customComponent === 'certificatePage') {
      // Bonafide Certificate Body
      doc.setFont('times', 'bold');
      doc.setFontSize(13);
      doc.setTextColor(30, 41, 59);
      doc.text("BONAFIDE CERTIFICATE", pageWidth / 2, currentY + 4, { align: 'center' });
      currentY += 12;

      doc.setFont('times', 'normal');
      doc.setFontSize(10.5);
      doc.setTextColor(51, 65, 85);

      const certText = `This is to certify that this Software Requirements Specification entitled "${metadata.projectTitle}: ${metadata.projectSubtitle}" is a bonafide record of technical requirements engineering work carried out by ${metadata.students.map(s => `${s.name} (${s.rollNo})`).join(', ')} under my supervision and guidance in partial fulfillment of the requirements for the award of the degree of ${metadata.degree} in Computer Science and Engineering during the academic year ${metadata.academicYear}.`;

      const lines = doc.splitTextToSize(certText, contentWidth);
      doc.text(lines, margin, currentY);
      currentY += lines.length * 5.5 + 8;

      // Student Declaration
      doc.setFont('times', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("DECLARATION OF ORIGINALITY BY CANDIDATES", margin, currentY);
      currentY += 6;

      doc.setFont('times', 'normal');
      doc.setFontSize(10);
      const declText = `We hereby declare that the specifications, architectures, algorithms, and interface designs contained within this document are original works conceived for the AI Project Mentor platform. We acknowledge adherence to academic honesty policies and engineering ethics prescribed by the university.`;
      const declLines = doc.splitTextToSize(declText, contentWidth);
      doc.text(declLines, margin, currentY);
      currentY += declLines.length * 5 + 15;

      // Approval Table & Signatures
      doc.setFont('times', 'bold');
      doc.setFontSize(11);
      doc.text("FORMAL REVIEW & APPROVAL SIGN-OFF", margin, currentY);
      currentY += 8;

      const sigBoxWidth = (contentWidth - 6) / 3;
      const sigBoxHeight = 44;

      // Guide Box
      doc.setDrawColor(203, 213, 225);
      doc.rect(margin, currentY, sigBoxWidth, sigBoxHeight);
      doc.setFont('times', 'bold');
      doc.setFontSize(9);
      doc.text("INTERNAL GUIDE", margin + 4, currentY + 7);
      doc.setFont('times', 'normal');
      doc.setFontSize(8.5);
      doc.text(metadata.guideName, margin + 4, currentY + 13);
      doc.text(metadata.guideDesignation, margin + 4, currentY + 18);
      doc.text("Signature: ________________", margin + 4, currentY + 36);

      // Coordinator Box
      const coordX = margin + sigBoxWidth + 3;
      doc.rect(coordX, currentY, sigBoxWidth, sigBoxHeight);
      doc.setFont('times', 'bold');
      doc.setFontSize(9);
      doc.text("PROJECT COORDINATOR", coordX + 4, currentY + 7);
      doc.setFont('times', 'normal');
      doc.setFontSize(8.5);
      doc.text(metadata.coordinatorName, coordX + 4, currentY + 13);
      doc.text("Associate Professor", coordX + 4, currentY + 18);
      doc.text("Signature: ________________", coordX + 4, currentY + 36);

      // HOD Box
      const hodX = margin + (sigBoxWidth + 3) * 2;
      doc.rect(hodX, currentY, sigBoxWidth, sigBoxHeight);
      doc.setFont('times', 'bold');
      doc.setFontSize(9);
      doc.text("HEAD OF DEPARTMENT", hodX + 4, currentY + 7);
      doc.setFont('times', 'normal');
      doc.setFontSize(8.5);
      doc.text(metadata.hodName, hodX + 4, currentY + 13);
      doc.text("HOD & Senior Professor", hodX + 4, currentY + 18);
      doc.text("Signature: ________________", hodX + 4, currentY + 36);

      currentY += sigBoxHeight + 12;

      // External Examiner Block
      doc.setDrawColor(148, 163, 184);
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, currentY, contentWidth, 32, 'FD');
      doc.setFont('times', 'bold');
      doc.setFontSize(9.5);
      doc.setTextColor(30, 41, 59);
      doc.text("EXTERNAL VIVA VOCE EXAMINER ENDORSEMENT", margin + 6, currentY + 7);
      doc.setFont('times', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text("External Examiner Name & Affiliation: __________________________________________________", margin + 6, currentY + 14);
      doc.text("Evaluation Recommendation: [  ] Approved without Revision   [  ] Approved with Minor Notes   [  ] Needs Revision", margin + 6, currentY + 21);
      doc.text("Examiner Signature with Institutional Seal: ____________________________    Date: ______________", margin + 6, currentY + 27);

      return;
    }

    // Render regular page sections
    page.sections.forEach((section) => {
      // Heading
      if (section.heading) {
        doc.setFont('times', 'bold');
        doc.setFontSize(11.5);
        doc.setTextColor(15, 23, 42);
        doc.text(section.heading, margin, currentY);
        currentY += 6;
      }

      // Subheading
      if (section.subheading) {
        doc.setFont('times', 'bold');
        doc.setFontSize(10.5);
        doc.setTextColor(30, 58, 138);
        doc.text(section.subheading, margin, currentY);
        currentY += 5;
      }

      // Paragraphs
      if (section.paragraphs) {
        doc.setFont('times', 'normal');
        doc.setFontSize(9.5);
        doc.setTextColor(51, 65, 85);
        section.paragraphs.forEach((p) => {
          const lines = doc.splitTextToSize(p, contentWidth);
          doc.text(lines, margin, currentY);
          currentY += lines.length * 4.4 + 3;
        });
      }

      // Bullets
      if (section.bullets) {
        doc.setFont('times', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(51, 65, 85);
        section.bullets.forEach((b) => {
          const lines = doc.splitTextToSize("•  " + b, contentWidth - 4);
          doc.text(lines, margin + 4, currentY);
          currentY += lines.length * 4.2 + 2;
        });
      }

      // Callouts
      if (section.callout) {
        doc.setDrawColor(199, 210, 254);
        doc.setFillColor(245, 247, 255);
        const calloutText = (section.callout.title ? `[${section.callout.title}] ` : "") + section.callout.text;
        const calloutLines = doc.splitTextToSize(calloutText, contentWidth - 10);
        const boxHeight = calloutLines.length * 4.2 + 8;
        
        doc.rect(margin, currentY, contentWidth, boxHeight, 'FD');
        doc.setFont('times', 'italic');
        doc.setFontSize(8.5);
        doc.setTextColor(30, 58, 138);
        doc.text(calloutLines, margin + 5, currentY + 5.5);
        currentY += boxHeight + 4;
      }

      // Tables
      if (section.table) {
        const table = section.table;
        const colCount = table.headers.length;
        const colWidth = contentWidth / colCount;
        const rowHeight = 7.5;

        // Table Header
        doc.setDrawColor(203, 213, 225);
        doc.setFillColor(241, 245, 249);
        doc.rect(margin, currentY, contentWidth, rowHeight, 'FD');
        
        doc.setFont('times', 'bold');
        doc.setFontSize(8.5);
        doc.setTextColor(15, 23, 42);

        table.headers.forEach((h, hIdx) => {
          const cellX = margin + hIdx * colWidth + 2;
          const text = doc.splitTextToSize(h, colWidth - 4);
          doc.text(text[0] || '', cellX, currentY + 5);
        });
        currentY += rowHeight;

        // Table Rows
        doc.setFont('times', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(51, 65, 85);

        table.rows.forEach((row, rIdx) => {
          if (currentY > pageHeight - 30) return; // avoid overflow
          
          doc.setFillColor(rIdx % 2 === 0 ? 255 : 249, rIdx % 2 === 0 ? 255 : 250, rIdx % 2 === 0 ? 255 : 251);
          doc.rect(margin, currentY, contentWidth, rowHeight, 'FD');

          row.forEach((cell, cIdx) => {
            const cellX = margin + cIdx * colWidth + 2;
            const textLines = doc.splitTextToSize(cell, colWidth - 4);
            doc.text(textLines[0] || '', cellX, currentY + 5);
          });
          currentY += rowHeight;
        });
        currentY += 4;
      }

      // ASCII Diagram
      if (section.diagram && section.diagram.asciiArt) {
        doc.setFont('times', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(30, 41, 59);
        doc.text(section.diagram.title, margin, currentY);
        currentY += 4;

        doc.setFillColor(248, 250, 252);
        doc.setDrawColor(226, 232, 240);

        const lines = section.diagram.asciiArt.trim().split('\n').slice(0, 16);
        const diaHeight = lines.length * 3.4 + 6;
        doc.rect(margin, currentY, contentWidth, diaHeight, 'FD');

        doc.setFont('courier', 'normal');
        doc.setFontSize(6.5);
        doc.setTextColor(51, 65, 85);

        lines.forEach((line, lIdx) => {
          doc.text(line, margin + 3, currentY + 4 + lIdx * 3.4);
        });

        currentY += diaHeight + 3;

        doc.setFont('times', 'italic');
        doc.setFontSize(8);
        doc.setTextColor(100, 116, 139);
        doc.text(section.diagram.caption, margin, currentY);
        currentY += 5;
      }

      currentY += 3;
    });
  });

  doc.save(`AI-Project-Mentor-SRS-IEEE830-${metadata.version}.pdf`);
}
